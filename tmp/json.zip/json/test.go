package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"os"
)

type human struct {
	Name string `json:"name"`
	Sex  string `json:"sex"`
	Age  int    `json:"age"`
	None string `json:"-"`
}

func main() {
	// 编码
	h := human{
		Name: "qingbing",
	}
	bs, _ := json.Marshal(h)
	//bs, _ := json.MarshalIndent(h, "", "  ")
	fmt.Println(string(bs))

	// 解码
	re := `{"name":"<qing>@q&q.com","age":33}`
	var h2 human
	err := json.Unmarshal([]byte(re), &h2)
	if err == nil {
		fmt.Printf("%+v\n", h2)
	} else {
		fmt.Printf("%#v", err)
	}

	// 编码到文件
	h3 := human{
		Name: "yongjin",
		Age:  22,
	}
	file, err := os.OpenFile("human.tmp", os.O_CREATE|os.O_WRONLY, os.ModePerm)
	if err == nil {
		defer file.Close()
		err = json.NewEncoder(file).Encode(&h3)
		if err != nil {
			fmt.Println("编码到文件失败")
		}
	} else {
		fmt.Println(err)
	}

	// 解析文件
	file, err = os.OpenFile("human.json", os.O_RDONLY, os.ModePerm)
	if err == nil {
		defer file.Close()
		var h4 human
		_ = json.NewDecoder(file).Decode(&h4)
		fmt.Printf("%+v\n", h4)
	} else {
		fmt.Println(err)
	}

	var b bytes.Buffer
	n, err := b.Write([]byte("Empl<>oy&ee info: \n"))
	if err != nil {
		fmt.Println(err)
	} else {
		fmt.Println("write", n)
	}
	err = json.Compact(&b, bs) //把json数据添加到buffer中去
	n1, err := b.WriteTo(os.Stdout)
	if err != nil {
		fmt.Println(err)
	} else {
		fmt.Println("write out", n1)
	}

	json.HTMLEscape(&b, bs)
	n1, err = b.WriteTo(os.Stdout)
	if err != nil {
		fmt.Println(err)
	} else {
		fmt.Println("write out", n1)
	}



	os.Exit(1)

	fmt.Println(json.Valid(bs))

	h51 := human{Name: "<qing>@q&q.com"}
	bs51, err := json.Marshal(h51)
	if err != nil {
		fmt.Printf("%#v", err)
	} else {
		fmt.Printf("%+v\n", string(bs51))
	}
}

//func Marshal(v any) ([]byte, error)
//func MarshalIndent(v any, prefix, indent string) ([]byte, error)
//func Unmarshal(data []byte, v any) error
//func NewDecoder(r io.Reader) *Decoder
//func NewEncoder(w io.Writer) *Encoder
//func Compact(dst *bytes.Buffer, src []byte) error
//func Valid(data []byte) bool
//func Indent(dst *bytes.Buffer, src []byte, prefix, indent string) error

//func HTMLEscape(dst *bytes.Buffer, src []byte)

//type Decoder struct{ ... }
//type Delim rune
//type Encoder struct{ ... }
//type InvalidUTF8Error struct{ ... }
//type InvalidUnmarshalError struct{ ... }
//type Marshaler interface{ ... }
//type MarshalerError struct{ ... }
//type Number string
//type RawMessage []byte
//type SyntaxError struct{ ... }
//type Token any
//type UnmarshalFieldError struct{ ... }
//type UnmarshalTypeError struct{ ... }
//type Unmarshaler interface{ ... }
//type UnsupportedTypeError struct{ ... }
//type UnsupportedValueError struct{ ... }
